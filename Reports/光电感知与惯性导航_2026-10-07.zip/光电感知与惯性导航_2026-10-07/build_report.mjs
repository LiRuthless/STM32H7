import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const markedPath=process.env.MARKED_PATH;
if(!markedPath) throw Error('Set MARKED_PATH to marked/lib/marked.esm.js');
const {marked}=await import(pathToFileURL(markedPath));
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const md=fs.readFileSync(path.join(root,'report.md'),'utf8');
const codeNames=['optical.py','inertial.py','demo.py','test_algorithms.py'];
let appendix='\n\n## 附录 完整可运行代码\n\n以下文件与下载目录中的代码一致，Python 3.10 及以上，仅依赖标准库。\n';
for(const f of codeNames) appendix+=`\n### ${f}\n\n\`\`\`python\n${fs.readFileSync(path.join(root,'code',f),'utf8')}\n\`\`\`\n`;
fs.writeFileSync(path.join(root,'report_full.md'),md+appendix,'utf8');
let content=marked.parse(md+appendix);
content=content.replace(/<img[^>]*src="([^"]+)"[^>]*>/g,(tag,src)=>{
  const f=decodeURIComponent(src);
  return ['流程图.svg','思维导图.svg'].includes(f)?fs.readFileSync(path.join(root,f),'utf8'):tag;
});
let sectionIndex=0;
const toc=[];
content=content.replace(/<h2>(.*?)<\/h2>/g,(tag,title)=>{
  const id='section-'+(++sectionIndex);
  toc.push(`<a href="#${id}">${title}</a>`);
  return `<h2 id="${id}">${title}</h2>`;
});
content=content.replace(/(<h1>.*?<\/h1>)/,`$1<details><summary>展开目录</summary><nav>${toc.join('<br>')}</nav></details>`);
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>光电感知与惯性导航 技术报告</title><style>
*{box-sizing:border-box}body{margin:0;background:#eaf0f5;color:#172633;font:16px/1.8 'Microsoft YaHei','Noto Sans CJK SC',sans-serif}main{max-width:1100px;margin:24px auto;padding:54px 60px;background:white;box-shadow:0 5px 24px #142d4512}h1{font-size:32px;line-height:1.4;color:#12354d}h2{font-size:25px;color:#12354d;margin-top:44px}h3{font-size:20px;margin-top:28px}h4{font-size:17px}p{margin:12px 0}a{color:#09659e;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}th,td{border:1px solid #cdd9e2;padding:9px 12px;text-align:left;vertical-align:top}th{background:#eaf2f7}tr:nth-child(even){background:#fafcfe}pre{background:#f0f5f8;border-radius:6px;padding:18px;overflow-x:auto;font:13px/1.6 Consolas,'Microsoft YaHei',monospace;white-space:pre-wrap;overflow-wrap:anywhere}code{font-family:Consolas,'Microsoft YaHei',monospace;font-size:0.9em}blockquote{margin:20px 0;padding:12px 20px;background:#eef7fc;border-left:4px solid #2982ae}svg{width:100%;height:auto;margin:20px 0}img{max-width:100%}.toolbar{position:sticky;top:0;background:#12354d;color:white;padding:10px 24px;z-index:2}.toolbar a{color:white;margin-right:20px}.toolbar button{padding:7px 14px;border:0;border-radius:4px;color:#12354d;cursor:pointer} @media(max-width:760px){main{padding:24px 18px}table{font-size:12px}h1{font-size:26px}}@media print{body{background:white;font-size:10.5pt}main{max-width:none;margin:0;padding:0;box-shadow:none}.toolbar{display:none}h2,h3,h4{break-after:avoid}tr{break-inside:avoid}pre{font-size:8pt}a{color:#172633} @page{size:A4;margin:18mm}}
</style></head><body><div class="toolbar"><a href="#">技术报告</a><a href="report_full.md" download>下载 Markdown</a><a href="交付包.zip" download>报告与代码包</a><button onclick="window.print()">打印 / 保存 PDF</button></div><main>${content}</main></body></html>`;
fs.writeFileSync(path.join(root,'光电感知与惯性导航_技术报告.html'),html,'utf8');
console.log(JSON.stringify({htmlCharacters:html.length,markdownCharacters:(md+appendix).length,codeFiles:codeNames}));
